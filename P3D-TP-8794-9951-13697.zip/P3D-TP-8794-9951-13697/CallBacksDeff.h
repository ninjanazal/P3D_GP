#pragma once
#include <iostream>


namespace P3D
{
	// callback para imprimir erros de execu�ao
	void DisplayErrorCallback(int error, const char* desc);
}