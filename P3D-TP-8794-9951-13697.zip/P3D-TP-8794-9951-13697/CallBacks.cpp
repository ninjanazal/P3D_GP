#pragma once
#include "CallBacksDeff.h"

// utiliza�ao do namespace
namespace P3D
{
	
}