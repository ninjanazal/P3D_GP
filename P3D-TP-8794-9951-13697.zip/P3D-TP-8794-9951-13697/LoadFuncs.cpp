#pragma once
#include "FileFuncs.h"

namespace P3D
{
#pragma region AuxFuncs
	// informa�ao sobre fun�oes presentes 
	std::string LoadFile(const char*);		// leitura de ficheiro nao binario
	void ShowTgaFileSize(const char* file_path);	// mostra tamanho do ficheiro

#pragma endregion AuxFuncs

	// confirma��o da existencia do ficheiro
	bool ConfirmFile(const char* kFile_path)
	{
		//Abre o ficheiro para leitura, caso consiga, o ficheiro existe
		std::fstream test_load(kFile_path, std::ios::in);

		// determina se o ficheiro consegue ser aberto
		std::cout << "Exists? : " << test_load.is_open() << std::endl;
		// retorna o valor de confirma�ao
		if (test_load.is_open())
		{
			// fecha o ficheiro
			test_load.close();
			return(true);
		}
		else {	// caso nao consia abrir
			test_load.close();	// fecha o ficheiro
			return(false);
		}
	}

	// carrega valores do objecto a partir do ficheiro xyz
	std::string LoadObjValues(const char* file_path, std::vector<glm::vec3>& vert,
		std::vector<glm::vec3>& norm, std::vector<glm::vec2>& tex_coord)
	{
		// limpa os vectores de vertices, normais e coordenadas de textura
		vert.clear(); norm.clear(); tex_coord.clear();

		std::string xyz_file = LoadFile(file_path);// carrega a informa�ao do ficheiro para string
		std::string material_found;		// material definido no ficheiro

		// determina se foi retornado valores 
		if (xyz_file.empty())
		{
			// se caso nao tenha retornado dados, indica que falhou a leitura
			std::cout << "Failed to read file!" << std::endl;
		}
		else
		{
			// caso tenha retornado dados			
			std::istringstream string_stream(xyz_file); // stream de leitura
			char read_buffer[256];	// buffer de leitura de linha
			// vars  para leitura de valores de vertices, normais e tex_Coords
			float temp_x, temp_y, temp_z;


			// inicia a extra�ao dos dados
			std::cout << "|--> Starting data object extraction..." << std::endl;

			// precorre linha a linha uzando um stream
			while (true)
			{
				// passa a palavra actual para o buffer de leitura
				string_stream >> read_buffer;

				// avalia se checou ao final do ficheiro
				if (string_stream.eof())
					break;	// salta fora do loop de leitura

				// para cada linha, avalia o tipo de dados
				// determina que tipo de informa�ao contida na linha
				if (std::strcmp(read_buffer, "mtllib") == 0)	// defini�ao de material
				{
					// nome do material encontrado
					string_stream >> material_found;	// nome do ficheiro � guardado					
					// indica que existe um material definido
					std::cout << "Material found: " << material_found << std::endl;;
				}
				else if (std::strcmp(read_buffer, "v") == 0)
				{
					// caso inicie por 'v' indica a leitura de vertices
					// extrai valores para variaveis temporarias
					string_stream >> temp_x >> temp_y >> temp_z;
					// com os valores extraidos sao adicionados ao vector de vetores
					vert.push_back(glm::vec3(temp_x, temp_y, temp_z));
				}
				else if (std::strcmp(read_buffer, "vt") == 0)
				{
					// caso inicie por "vt", inicia a leitura das coordenadas de textura
					// extrai valores para variaveis temporariasa
					string_stream >> temp_x >> temp_y;
					// com os valores extraidos, adiciona-se ao vector de coordenadas de textura
					tex_coord.push_back(glm::vec2(temp_x, temp_y));
				}
				else if (std::strcmp(read_buffer, "vn") == 0)
				{
					// caso inicie por "vn", inicia a leitura do valor de normais
					// extrai valores para variaveis temporarias
					string_stream >> temp_x >> temp_y >> temp_z;
					// com valores extraidos, adiciona-se ao vector de normais
					norm.push_back(glm::vec3(temp_x, temp_y, temp_z));
				}
			}
		}

		// returna se encontrou um material, a variavel vai vazia caso nao exista
		// material definido
		return material_found;
	}

	// carrega valores do material a partir do ficheiro mtl
	std::string LoadObjMaterialValues(const char* file_path, glm::vec3(&coef)[3], float& spec_exp)
	{
		// define uma string com toda a informa�ao presente no ficheiro
		std::string mtl_file = LoadFile(file_path);
		std::string texture_found;	// nome da textura encontrada

		if (mtl_file.empty())
			// indica que falhou a leitura do ficheiro
			std::cout << "Failed to read file" << std::endl;
		else
		{
			// caso tenha retornado dados
			std::istringstream string_stream(mtl_file);	// stream de leitura
			char read_buffer[256];	// buffer de leitura
			// variaveis temporarias de leitura para valores presentes
			float temp_x, temp_y, temp_z;

			// inicia a extra�ao de dados
			std::cout << "|--> Start material data extraction..." << std::endl;

			// precorre linha usando stream de leitura
			while (true)
			{
				// passa a palavra actual para o buffer de leitura
				string_stream >> read_buffer;

				// avalia o final da stream
				if (string_stream.eof())
					break;	// salta o ciclo assim que atingir o final do ficheiro

				// para cada linha avalia o tipo de dados
				// determina o tipo de informa�ao representado na linha					
				if (std::strcmp(read_buffer, "Ka") == 0)
				{
					// caso inicie por "ka", inicia a leitura do coeficiente de reflexao
					// de luz ambiente, coef[0]
					string_stream >> temp_x >> temp_y >> temp_z;
					// com valores extraidos, adiciona ao array de coeficientes na posi�ao 0
					coef[0] = glm::vec3(temp_x, temp_y, temp_z);
				}
				else if (std::strcmp(read_buffer, "Kd") == 0)
				{
					// caso inicie por "kd", inicia a leitura de coeficiente de reflexao
					// de luz difusa, coef[1]
					string_stream >> temp_x >> temp_y >> temp_z;
					// com os valores extraidos, adiciona ao array de coeficientes na posi�ao 1
					coef[1] = glm::vec3(temp_x, temp_y, temp_z);
				}
				else if (std::strcmp(read_buffer, "Ks") == 0)
				{
					// caso inicie por "ks", inicia a leitura de coeficiente de reflexao
					// de luz especular
					string_stream >> temp_x >> temp_y >> temp_z;
					// com os valores extraidos, adiciona ao array de coeficientes na posi�ao 2
					coef[2] = glm::vec3(temp_x, temp_y, temp_z);
				}
				else if (std::strcmp(read_buffer, "Ns") == 0)
				{
					// caso inicie por "ns", inicia a leitura do expoente especular
					string_stream >> spec_exp;
				}
				else if (std::strcmp(read_buffer, "map") == 0)
				{
					// caso inicie por "map", guarda o nome do ficheiro de textura
					string_stream >> texture_found;
					// indica que existe uma textura
					std::cout << "Texture Map found -> " << texture_found << std::endl;
				}
				else
					// para os valores restantes de informa�ao sao ignorados
					string_stream.getline(read_buffer, 256);
			}
		}

		// retorna se encontrou uma textura, a variavel retorna vazia caso nao
		// exista textura definida
		return texture_found;
	}

	// leitura do ficheiro de textura
	unsigned char* LoadTextureValues(const char* file_path,
		GLint& tex_width, GLint& tex_height, GLint& tex_chan)
	{
		// Mostra tamano do ficheiro
		ShowTgaFileSize(file_path);

		// incia a leitura da imagem utilizando a lib stb_image
		// informa
		std::cout << "Start loading texture file..." << std::endl;

		// define a leitura da imagem verticalmente, para que a interpreta�ao seja igual ao OpenGl
		stbi_set_flip_vertically_on_load(true);

		// guarda a informa�ao retornada num buffer interno
		unsigned char* data_to = (unsigned char*)stbi_load(file_path, &tex_width, &tex_height, &tex_chan, 0);

		// informa que a textura foi carregada
		if (data_to != NULL) {
			// se existir dados de imagem imprime
			std::cout << "|--> Image loded successfully!\n|---->Image Size: " <<
				tex_width << " x " <<   tex_height << " ::: channels: " << tex_chan << std::endl;
		}
		// retorna os dados
		return data_to;
	}

	// leitura de valores de shader
	std::string LoadShader(const char* file_path)
	{
		// inicia um buffer de leitura
		std::string shader_data;
		// abre o ficheiro para leitura em binario, coloca o ponteiro no fim do ficheiiro
		std::ifstream shader_load_stream(file_path,
			std::ifstream::in | std::ifstream::binary | std::ifstream::ate);

		// verifica se abrio o ficheiro
		if (shader_load_stream.is_open())
		{
			// guarda o tamanho do ficheiro
			size_t file_size = shader_load_stream.tellg();
			// coloca o ponteiro de leitura de volta no inicio do ficheiro
			shader_load_stream.seekg(0, std::ifstream::beg);

			// cria espa�o em memoria para os dados
			char* data_to = new char[file_size + size_t(1)];
			shader_load_stream.read(data_to, file_size);	// le para o tempArray os dados do ficheiro

			// marca o final da string
			data_to[file_size] = 0;
			// guarda os dados lidos na string de retorno
			shader_data = data_to;
			// elimina o array temporario
			delete[] data_to;

			// informa que o ficheiro foi carregado com sucesso
			std::cout << "-> Shader File loaded to mem..." << std::endl;
		}
		// fecha o ficheiro de leitura
		shader_load_stream.close();
		// retorna a informa�ao carregada
		return shader_data;
	}

	// fun�oes axiliariares
#pragma region Helpers
	// fun�ao auxiliar para carregar ficheiro nao binario
	std::string LoadFile(const char* file_path)
	{
		std::string file_data;	// informa�ao do ficheiro

		// abre o ficheiro para leitura, anteriormente confirmado, coloca o ponteiro no fim do ficheiro
		std::ifstream file_load_stream(file_path, std::ifstream::in | std::ifstream::ate);

		// confirma se o ficheiro foi abert
		if (file_load_stream.is_open())
		{
			// guarda o tamanho do ficheiro em bits
			size_t file_size = file_load_stream.tellg();
			// coloca o leitor de volta ao inicio do ficheiro
			file_load_stream.seekg(0, std::ifstream::beg);

			// cria espa�o em memoria para os dados
			char* data_to = new char[file_size + size_t(1)]{};
			file_load_stream.read(data_to, file_size);	// l� para tempArray os dados do ficheiro

			// marca o final da string 
			data_to[file_size] = 0;
			// guarda os dados lidos na string
			file_data = data_to;
			// elimina o tempArray
			delete[] data_to;

			// imprime que o ficheiro foi carregado com sucesso
			std::cout << "-> File loaded to mem..." << std::endl;
		}
		// fecha o ficheiro de leitura
		file_load_stream.close();
		// retorna a informa�ao carregada do ficheiro
		return file_data;
	}

	// fun�ao auxiliar para carregar ficheiros binarios
	void ShowTgaFileSize(const char* file_path)
	{
		// abre o ficheiro para leitura, confirmado anteriormente, coloco o ponteiro no fim do ficheiro
		std::fstream file_load_bin_stream(file_path, std::ios::in | std::ios::binary | std::ios::ate);

		// confirma se o ficheiro foi aberto
		if (file_load_bin_stream.is_open())
		{
			// guarda o tamanho do ficheiro em bits
			size_t file_size = file_load_bin_stream.tellg();

			// imprime o tamanho do ficheiro
			std::cout << "Tga file size: " << static_cast<int>(file_size) << " bytes" << std::endl;
		}
		// fecha o ficheiro de leitura
		file_load_bin_stream.close();

	}
#pragma endregion Helpers
}
